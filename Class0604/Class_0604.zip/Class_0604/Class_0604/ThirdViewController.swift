//
//  ThirdViewController.swift
//  Class_0604
//
//  Created by seob on 2018. 6. 4..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("-----third viewDidAppear-----------")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewWillAppear-----------")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewWillDisappear-----------")
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewDidDisappear-----------")
    }
    
    
    @IBAction private func dismissViewController(_ sender: Any){
        //없애는 역할 pressntingviewcontroller?.dismiss(animated:)
        dismiss(animated: true) {
            print("dismissed third view controller")
        }
//        dismiss(animated: true)
//        presentingViewController?.dismiss(animated: true)
        
    }
    deinit {
        print("deinit")
    }
}
