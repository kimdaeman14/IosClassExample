//
//  SecondViewController.swift
//  Class_0604
//
//  Created by seob on 2018. 6. 4..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .yellow
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction private func showThirdViewController(_ button: UIButton){
       let thridstoryboard = UIStoryboard.init(name: "Main", bundle: nil)
        
        let thridViewController = thridstoryboard.instantiateViewController(withIdentifier: "ThirdViewController")
        present(thridViewController, animated: true)
    }
    
    @IBAction private func seondDimissViewController(_ sender: Any){
        presentingViewController?.dismiss(animated: true, completion: {
            print("second dismiss")
        })
    }
    
    deinit {
        print("send deinit")
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("-----third viewDidAppear-----------")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewWillAppear-----------")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewWillDisappear-----------")
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewDidDisappear-----------")
    }

}
