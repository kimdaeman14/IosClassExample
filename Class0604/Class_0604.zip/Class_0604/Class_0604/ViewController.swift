//
//  ViewController.swift
//  Class_0604
//
//  Created by seob on 2018. 6. 4..
//  Copyright © 2018년 seob. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }


    @IBAction private func showNextViewController(_ sender: Any){
//        let secondViewController = SecondViewController(nibName: secondViewController , bundle: nil)
//        let secondViewController = SecondViewController()
//            present(secondViewController , animated:  true){
//            print("present second view controller")
//        }
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let secondViewController = storyboard.instantiateViewController(withIdentifier: "SecondViewController")
        present(secondViewController, animated: true)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        print("-----third viewDidAppear-----------")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewWillAppear-----------")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewWillDisappear-----------")
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        print("-----third viewDidDisappear-----------")
    }
}

